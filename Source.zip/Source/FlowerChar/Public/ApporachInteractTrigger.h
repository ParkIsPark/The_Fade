// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "TFTrigger.h"
#include "ApporachInteractTrigger.generated.h"

/**
 * 
 */
UCLASS()
class FLOWERCHAR_API AApporachInteractTrigger : public ATFTrigger
{
	GENERATED_BODY()

public:

	virtual void OnPlayerTrigger() override; // �ӽ� ����
	
};
